#!/bin/bash
# Lake-OS 开发聚合工作站
# 完整的编译链，多种语言环境，容器化支持

echo "[Lake-Dev-Kit] Installing ultimate development tools..."
apt-get update
apt-get install -y --no-install-recommends \
    build-essential cmake ninja-build gdb \
    gcc clang \
    python3 python3-pip python3-venv \
    nodejs npm golang \
    git curl wget jq \
    docker.io docker-compose-v2 \
    qemu-system-arm qemu-system-x86 qemu-user-static

echo "[Lake-Dev-Kit] Development tools installation complete."
