#!/bin/bash
# Lake-OS 渗透测试工具栈
# 稳定性超越 Kali，工具集同样丰富

echo "[Lake-Security-Kit] Installing ultimate pentest stack..."
apt-get update
apt-get install -y --no-install-recommends \
    nmap tcpdump wireshark tshark \
    john hashcat hydra sqlmap \
    metasploit-framework aircrack-ng \
    netcat-traditional socat \
    dirb gobuster \
    python3-impacket python3-scapy

echo "[Lake-Security-Kit] Pentest stack installation complete."
