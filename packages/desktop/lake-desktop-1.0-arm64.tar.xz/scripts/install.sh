#!/bin/bash
# Lake-OS 自研桌面基础组件
# 基于 Wayland + Sway 的极致精简版，低内存高刷新率

echo "[Lake-Desktop] Installing ultimate desktop environment..."
apt-get update
apt-get install -y --no-install-recommends \
    sway swaybg swayidle swaylock waybar \
    alacritty wofi mako-notifier thunar \
    polkit-kde-agent-1 qtwayland5 qt6-wayland xwayland \
    fonts-noto fonts-noto-cjk fonts-ubuntu-console
    
echo "[Lake-Desktop] Desktop environment installation complete."
