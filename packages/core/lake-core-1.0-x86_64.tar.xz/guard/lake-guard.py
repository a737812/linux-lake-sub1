#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Linux-Lake-OS 守护进程 (Lake-Guard)
自动监控系统状态并执行智能节流。
"""
import os
import time
import subprocess

def log(msg):
    print(f"[Lake-Guard] {msg}")

def check_mem():
    """检查内存，如果极低则尝试清空缓存"""
    try:
        with open("/proc/meminfo") as f:
            lines = f.readlines()
            total = available = 0
            for line in lines:
                if line.startswith("MemTotal:"):
                    total = int(line.split()[1])
                elif line.startswith("MemAvailable:"):
                    available = int(line.split()[1])
            if total > 0 and (available / total) < 0.1: # 可用少于 10%
                log("内存不足 10%，触发紧急缓存清理！")
                subprocess.run("sync; echo 3 > /proc/sys/vm/drop_caches", shell=True)
    except Exception as e:
        pass

def main():
    if os.geteuid() != 0:
        print("Lake-Guard 需要 root 权限运行。")
        return

    log("智能调度守护进程启动...")
    while True:
        check_mem()
        # 这里可以扩展检测后台进程 CPU 占用并 renice
        time.sleep(30)

if __name__ == "__main__":
    main()